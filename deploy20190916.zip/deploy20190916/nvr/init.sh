echo 123456 | sudo -S ls
sudo cp -rf lib* /usr/lib/x86_64-linux-gnu
sudo cp -rf ./HCNetSDKCom/lib* /usr/lib/x86_64-linux-gnu
sudo chmod +x nvr.out

echo 123456 | sudo apt -y install libmysqlclient-dev
echo 123456 | sudo apt -y install libmp4v2-dev
echo 123456 | sudo apt install -y libboost-all-dev
echo 123456 | sudo apt install -y libcurl4-openssl-dev
