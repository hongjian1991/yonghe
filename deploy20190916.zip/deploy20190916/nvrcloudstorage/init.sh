sudo cp -rf lib* /usr/lib/x86_64-linux-gnu
chmod +x nvrslice
chmod +x nvrcloudstorage
chmod +x watchdogslice.sh
